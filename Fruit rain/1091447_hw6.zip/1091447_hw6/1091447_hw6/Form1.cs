﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace _1091447_hw6
{
    public partial class Form1 : Form
    {
        int time = 120;
        int score = 0;
        Image img;
        bool back = false;
        PictureBox[] fruit = new PictureBox[3];
        Random r = new Random();//讓水果在隨機的位子掉落
        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer3.Interval = 1000 * 10;
            for (int i = 0; i < 3; i++)
            {
                fruit[i] = new PictureBox();
            }
            fruit[0].Image = Properties.Resources.StawBerry;
            fruit[1].Image = Properties.Resources.Tomato;
            fruit[2].Image = Properties.Resources.Banana;

            pictureBox1.BackColor = Color.Transparent;
            for (int i = 0; i < 3; i++)
            {
                int tem = r.Next(300);
                fruit[i].Left = tem;
                fruit[i].Top += i * 60;
                fruit[i].BackColor = Color.Transparent;//背景透明(png)
                this.Controls.Add(fruit[i]);
            }
            img = Properties.Resources._1;//背景
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Location.X >= 300)
                pictureBox1.Left = 300;
            else
                pictureBox1.Left = e.Location.X;
            this.Invalidate();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (!back)//檢查背景
            {
                img = Properties.Resources._2;
                img = img.GetThumbnailImage(500, 300, null, (IntPtr)0);
                back = true;
            }
            else if (back)
            {
                img = Properties.Resources._1;
                img = img.GetThumbnailImage(540, 300, null, (IntPtr)0);
                back = false;
            }
            this.Invalidate();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                fruit[i].Top++;
                if (fruit[i].Bottom == 270)
                {
                    if ((pictureBox1.Right >= fruit[i].Left && pictureBox1.Left < fruit[i].Left) || (pictureBox1.Left >= fruit[i].Left && pictureBox1.Right <= fruit[i].Right) ||
                                             (pictureBox1.Left <= fruit[i].Right && pictureBox1.Right >= fruit[i].Right))
                    {
                        score++;
                    }
                    int tem = r.Next(300);
                    fruit[i].Left = tem;
                    fruit[i].Top = 30;
                    label2.Text = "Received: " + score;
                }
            }

            this.Invalidate();
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            time = 120;
            score = 0;
            label1.Text = "Remaining: " + time.ToString() + " seconds";
            label2.Text = "Received: " + score;
            for (int i = 0; i < 3; i++)
            {
                int tem = r.Next(300);
                fruit[i].Left = tem;
                fruit[i].Top = 30 + i * 50;
            }
            timer3.Stop();
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time--;
            label1.Text = "Remaining: " + time.ToString() + " seconds";
            if (time == 0)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            float[][] cmArray1 =
       {
                  new float[] {1, 0, 0, 0,    0},
                  new float[] {0, 1, 0, 0,    0},
                  new float[] {0, 0, 1, 0,    0},
                  new float[] {0, 0, 0, (float)0.3,    0},
                  new float[] {0, 0, 0, 0,     1}
               };
            ColorMatrix cm1 = new ColorMatrix(cmArray1);
            ImageAttributes ia1 = new ImageAttributes();
            ia1.SetColorMatrix(cm1,
                ColorMatrixFlag.Default,
                ColorAdjustType.Bitmap);
            // 繪出透明的背景影像
            Rectangle rectDest = new Rectangle(0, 0, 350, 250);
            e.Graphics.DrawImage(img,
                rectDest,
                0, 0, img.Width, img.Height,
                GraphicsUnit.Pixel, ia1);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
