﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1091447_hw2
{
    public partial class Form1 : Form
    {
        int[] checkmap = new int[] { -1, -1, -1, -1, -1, -1, -1, -1, -1 };
        int[] x = new int[] { 0, 60, 120 };
        int[] y = new int[] { 0, 60, 120 };
        int[] w = new int[] { 6, 54, 66, 114, 174 };
        int[] h = new int[] { 6, 54, 66, 114, 174 };
        int times = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Pen p1 = new Pen(Color.Black, 5);
            Graphics gg = this.CreateGraphics();
            times = 0;
            for (int i = 0; i <= 2; i++)
            {
                for (int j = 0; j <= 2; j++)
                {
                    gg.DrawRectangle(p1, x[j], y[i], 60, 60);
                }
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Pen bluepen = new Pen(Color.Blue, 3);
            Pen redpen = new Pen(Color.Red, 3);

            Random rd1 = new Random(Guid.NewGuid().GetHashCode());
            Random rd2 = new Random(Guid.NewGuid().GetHashCode());
            //叉叉屬性設定
            //產生0~8的亂數

            int ws = rd1.Next(3);
            int hs = rd2.Next(3);
            int computerindex = ws + hs * 3;
            Point p1 = new Point(6 + 60 * ws, 6 + 60 * hs);
            Point p2 = new Point(54 + 60 * ws, 6 + 60 * hs);
            Point p3 = new Point(54 + 60 * ws, 54 + 60 * hs);
            Point p4 = new Point(6 + 60 * ws, 54 + 60 * hs);
            Rectangle computerrec = new Rectangle(6 + 60 * ws, 6 + 60 * hs, 48, 48);//叉叉所代表的方格
            Graphics g = this.CreateGraphics();
            //------------------------------------------------------------------------------------------------------------

            //圈圈屬性設定
            Rectangle r1 = new Rectangle(6, 6, 48, 48);
            Rectangle r2 = new Rectangle(66, 6, 48, 48);
            Rectangle r3 = new Rectangle(126, 6, 48, 48);
            Rectangle r4 = new Rectangle(6, 66, 48, 48);
            Rectangle r5 = new Rectangle(66, 66, 48, 48);
            Rectangle r6 = new Rectangle(126, 66, 48, 48);
            Rectangle r7 = new Rectangle(6, 126, 48, 48);
            Rectangle r8 = new Rectangle(66, 126, 48, 48);
            Rectangle r9 = new Rectangle(126, 126, 48, 48);

            //判斷使用者滑鼠位置並畫圈
            if (r1.Contains(e.Location.X, e.Location.Y) && checkmap[0] == -1)
            {
                g.DrawEllipse(bluepen, r1);
                checkmap[0] = 0;
            }
            else if (r2.Contains(e.Location.X, e.Location.Y) && checkmap[1] == -1)
            {
                g.DrawEllipse(bluepen, r2);
                checkmap[1] = 0;
            }
            else if (r3.Contains(e.Location.X, e.Location.Y) && checkmap[2] == -1)
            {
                g.DrawEllipse(bluepen, r3);
                checkmap[2] = 0;
            }
            else if (r4.Contains(e.Location.X, e.Location.Y) && checkmap[3] == -1)
            {
                g.DrawEllipse(bluepen, r4);
                checkmap[3] = 0;
            }
            else if (r5.Contains(e.Location.X, e.Location.Y) && checkmap[4] == -1)
            {
                g.DrawEllipse(bluepen, r5);
                checkmap[4] = 0;
            }
            else if (r6.Contains(e.Location.X, e.Location.Y) && checkmap[5] == -1)
            {
                g.DrawEllipse(bluepen, r6);
                checkmap[5] = 0;
            }
            else if (r7.Contains(e.Location.X, e.Location.Y) && checkmap[6] == -1)
            {
                g.DrawEllipse(bluepen, r7);
                checkmap[6] = 0;
            }
            else if (r8.Contains(e.Location.X, e.Location.Y) && checkmap[7] == -1)
            {
                g.DrawEllipse(bluepen, r8);
                checkmap[7] = 0;
            }
            else if (r9.Contains(e.Location.X, e.Location.Y) && checkmap[8] == -1)
            {
                g.DrawEllipse(bluepen, r9);
                checkmap[8] = 0;
            }
            times++;
            //判斷電腦下的位置是否跟玩家重複，如果重複，則重新挑一個位置
            while (checkmap[computerindex] != -1)
            {
                if (times > 4) break;
                ws = rd1.Next(3);
                hs = rd2.Next(3);
                computerindex = ws + hs * 3;
                p1 = new Point(6 + 60 * ws, 6 + 60 * hs);
                p2 = new Point(54 + 60 * ws, 6 + 60 * hs);
                p3 = new Point(54 + 60 * ws, 54 + 60 * hs);
                p4 = new Point(6 + 60 * ws, 54 + 60 * hs);
            }
            //畫叉叉
            if (times <= 4)
            {
                g.DrawLine(bluepen, p1, p3);
                g.DrawLine(bluepen, p2, p4);
                checkmap[computerindex] = 1;
            }

            if ((checkmap[0] == 0 && checkmap[1] == 0 && checkmap[2] == 0) ||
            (checkmap[3] == 0 && checkmap[4] == 0 && checkmap[5] == 0) ||
            (checkmap[6] == 0 && checkmap[7] == 0 && checkmap[8] == 0) ||
            (checkmap[0] == 0 && checkmap[3] == 0 && checkmap[6] == 0) ||
            (checkmap[1] == 0 && checkmap[4] == 0 && checkmap[7] == 0) ||
            (checkmap[2] == 0 && checkmap[5] == 0 && checkmap[8] == 0) ||
            (checkmap[0] == 0 && checkmap[4] == 0 && checkmap[8] == 0) ||
            (checkmap[2] == 0 && checkmap[4] == 0 && checkmap[6] == 0))
            {
                if (checkmap[0] == 0 && checkmap[1] == 0 && checkmap[2] == 0)
                {
                    Point a = new Point(6, 30);
                    Point b = new Point(174, 30);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[3] == 0 && checkmap[4] == 0 && checkmap[5] == 0)
                {
                    Point a = new Point(6, 90);
                    Point b = new Point(174, 90);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[6] == 0 && checkmap[7] == 0 && checkmap[8] == 0)
                {
                    Point a = new Point(6, 150);
                    Point b = new Point(174, 150);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[0] == 0 && checkmap[3] == 0 && checkmap[6] == 0)
                {
                    Point a = new Point(30, 6);
                    Point b = new Point(30, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[1] == 0 && checkmap[4] == 0 && checkmap[7] == 0)
                {
                    Point a = new Point(90, 6);
                    Point b = new Point(90, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[2] == 0 && checkmap[5] == 0 && checkmap[8] == 0)
                {
                    Point a = new Point(150, 6);
                    Point b = new Point(150, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[0] == 0 && checkmap[4] == 0 && checkmap[8] == 0)
                {
                    Point a = new Point(6, 6);
                    Point b = new Point(174, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[2] == 0 && checkmap[4] == 0 && checkmap[6] == 0)
                {
                    Point a = new Point(174, 6);
                    Point b = new Point(6, 174);
                    g.DrawLine(redpen, a, b);
                }
                label1.Text = "you win";
            }
            else if ((checkmap[0] == 1 && checkmap[1] == 1 && checkmap[2] == 1) ||
                    (checkmap[3] == 1 && checkmap[4] == 1 && checkmap[5] == 1) ||
                    (checkmap[6] == 1 && checkmap[7] == 1 && checkmap[8] == 1) ||
                    (checkmap[0] == 1 && checkmap[3] == 1 && checkmap[6] == 1) ||
                    (checkmap[1] == 1 && checkmap[4] == 1 && checkmap[7] == 1) ||
                    (checkmap[2] == 1 && checkmap[5] == 1 && checkmap[8] == 1) ||
                    (checkmap[0] == 1 && checkmap[4] == 1 && checkmap[8] == 1) ||
                    (checkmap[2] == 1 && checkmap[4] == 1 && checkmap[6] == 1))
            {
                if (checkmap[0] == 1 && checkmap[1] == 1 && checkmap[2] == 1)
                {
                    Point a = new Point(6, 30);
                    Point b = new Point(174, 30);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[3] == 1 && checkmap[4] == 1 && checkmap[5] == 1)
                {
                    Point a = new Point(6, 90);
                    Point b = new Point(174, 90);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[6] == 1 && checkmap[7] == 1 && checkmap[8] == 1)
                {
                    Point a = new Point(6, 150);
                    Point b = new Point(174, 150);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[0] == 1 && checkmap[3] == 1 && checkmap[6] == 1)
                {
                    Point a = new Point(30, 6);
                    Point b = new Point(30, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[1] == 1 && checkmap[4] == 1 && checkmap[7] == 1)
                {
                    Point a = new Point(90, 6);
                    Point b = new Point(90, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[2] == 1 && checkmap[5] == 1 && checkmap[8] == 1)
                {
                    Point a = new Point(150, 6);
                    Point b = new Point(150, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[0] == 1 && checkmap[4] == 1 && checkmap[8] == 1)
                {
                    Point a = new Point(6, 6);
                    Point b = new Point(174, 174);
                    g.DrawLine(redpen, a, b);
                }
                else if (checkmap[2] == 1 && checkmap[4] == 1 && checkmap[6] == 1)
                {
                    Point a = new Point(174, 6);
                    Point b = new Point(6, 174);
                    g.DrawLine(redpen, a, b);
                }
                label1.Text = "you lose";
            }
            else if (times < 5)
            {

            }
            else
            {
                label1.Text = "draw";
            }
        }

        private void restarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pen p1 = new Pen(Color.Black, 5);
            Graphics gg = this.CreateGraphics();
            gg.Clear(Color.White);
            times = 0;
            for (int i = 0; i <= 2; i++)
            {
                for (int j = 0; j <= 2; j++)
                {
                    gg.DrawRectangle(p1, x[j], y[i], 60, 60);
                }
            }
            for (int i = 0; i < 9; i++)
            {
                checkmap[i] = -1;
            }
        }
    }
}
