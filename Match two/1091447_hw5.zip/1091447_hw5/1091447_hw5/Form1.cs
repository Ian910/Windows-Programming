﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace _1091447_hw5
{
    public partial class Form1 : Form
    {
        Image back = Image.FromFile("C:\\Users\\k2349\\OneDrive\\Desktop\\1091447_hw5\\1091447_hw5\\8_0.jpg");
        Image[] fruit = new Image[17];
        int[] map = new int[8];
        int[] checklist = new int[17];
        int second = 0;
        int x1 = 0;
        int x2 = 100;
        int x3 = 200;
        int x4 = 300;

        int y1 = 0;
        int y2 = 100;
        int y3 = 200;
        int y4 = 300;
        int wid = 100;
        int len = 100;
        int index = 1;
        int preindex = 0;
        //j1,i1是紀錄水果圖要畫在哪個方格裡
        //j2、i2紀錄j1,i1
        int nowj, nowi, prej, prei;

        bool stayin = true;

        private void Form1_Load(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            drawmulsquare();
            for (int i = 5; i <= 305; i += 100)
            {
                for (int j = 5; j <= 305; j += 100)
                {
                    g.DrawImage(back, i, j, 90, 90);
                }
            }
        }

        private void restarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            drawmulsquare();
            for (int i = 5; i <= 305; i += 100)
            {
                for (int j = 5; j <= 305; j += 100)
                {
                    g.DrawImage(back, i, j, 90, 90);
                }
            }
            second = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            second++;
            label1.Text = "Second: " + second.ToString();
        }
        private void drawmulsquare()
        {
            Graphics g = this.CreateGraphics();
            g.DrawRectangle(Pens.Black, x1, y1, wid, len);
            g.DrawRectangle(Pens.Black, x2, y1, wid, len);
            g.DrawRectangle(Pens.Black, x3, y1, wid, len);
            g.DrawRectangle(Pens.Black, x4, y1, wid, len);
            g.DrawRectangle(Pens.Black, x1, y2, wid, len);
            g.DrawRectangle(Pens.Black, x2, y2, wid, len);
            g.DrawRectangle(Pens.Black, x3, y2, wid, len);
            g.DrawRectangle(Pens.Black, x4, y2, wid, len);
            g.DrawRectangle(Pens.Black, x1, y3, wid, len);
            g.DrawRectangle(Pens.Black, x2, y3, wid, len);
            g.DrawRectangle(Pens.Black, x3, y3, wid, len);
            g.DrawRectangle(Pens.Black, x4, y3, wid, len);
            g.DrawRectangle(Pens.Black, x1, y4, wid, len);
            g.DrawRectangle(Pens.Black, x2, y4, wid, len);
            g.DrawRectangle(Pens.Black, x3, y4, wid, len);
            g.DrawRectangle(Pens.Black, x4, y4, wid, len);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            drawmulsquare();
            for (int i = 5; i <= 305; i += 100)
            {
                for (int j = 5; j <= 305; j += 100)
                {
                    g.DrawImage(back, i, j, 90, 90);
                }
            }
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            //如果全部水果都用過了就不動作
            //紀錄該水果出現的次數
            //把該水果顯示在九宮格
            Graphics g = this.CreateGraphics();

            for (int i = 5; i <= 305; i += 100)
            {
                for (int j = 5; j <= 305; j += 100)
                {
                    if (e.Location.X > j && e.Location.X < j + 100 && e.Location.Y > i && e.Location.Y < i + 100)
                    {
                        if (j == 5 && i == 5)
                        {
                            index = 1;
                        }
                        else if (j == 105 && i == 5)
                        {
                            index = 2;
                        }
                        else if (j == 205 && i == 5)
                        {
                            index = 3;
                        }
                        else if (j == 305 && i == 5)
                        {
                            index = 4;
                        }
                        else if (j == 5 && i == 105)
                        {
                            index = 5;
                        }
                        else if (j == 105 && i == 105)
                        {
                            index = 6;
                        }
                        else if (j == 205 && i == 105)
                        {
                            index = 7;
                        }
                        else if (j == 305 && i == 105)
                        {
                            index = 8;
                        }
                        else if (j == 5 && i == 205)
                        {
                            index = 9;
                        }
                        else if (j == 105 && i == 205)
                        {
                            index = 10;
                        }
                        else if (j == 205 && i == 205)
                        {
                            index = 11;
                        }
                        else if (j == 305 && i == 205)
                        {
                            index = 12;
                        }
                        else if (j == 5 && i == 305)
                        {
                            index = 13;
                        }
                        else if (j == 105 && i == 305)
                        {
                            index = 14;
                        }
                        else if (j == 205 && i == 305)
                        {
                            index = 15;
                        }
                        else if (j == 305 && i == 305)
                        {
                            index = 16;
                        }
                        g.DrawImage(fruit[index], j, i, 90, 90);
                        nowj = j;
                        nowi = i;

                    }

                }
            }

            if (!firsttime)
            {
                if (checklist[index] != checklist[preindex])
                {
                    Thread.Sleep(1000);
                    g.DrawImage(back, nowj, nowi, 90, 90);
                    g.DrawImage(back, prej, prei, 90, 90);
                }

                firsttime = true;
            }
            else
            {
                prej = nowj;
                prei = nowi;
                preindex = index;
                firsttime = false;

            }
        }

        bool firsttime = true;
        int count = 0;
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 8; i++)
            {
                map[i] = 0;
            }
            fruit[0] = Image.FromFile("C:\\Users\\showp\\OneDrive\\Desktop\\1091419_作業五\\1091419_作業五\\8_0.jpg");
            for (int x = 1; x <= 16; x++)
            {

                Random rd = new Random(Guid.NewGuid().GetHashCode());
                int r = rd.Next(8);
                if (map[r] >= 2)
                {
                    while (map[r] >= 2)
                    {
                        r = rd.Next(8);
                    }
                }
                checklist[x] = r;
                map[r]++;
                string s;
                s = (r + 1).ToString();
                fruit[x] = Image.FromFile("C:\\Users\\showp\\OneDrive\\Desktop\\1091419_作業五\\1091419_作業五\\8_" + s + ".jpg");
            }
        }
    }
}
