﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1091447_hw4
{
    public partial class Form1 : Form
    {
        Point ballPt = new Point(150, 175);
        Color c = Color.Red;
        Brush mousebrush = new SolidBrush(Color.Red);
        Boolean stop = false;
        int ballx = 1;
        int bally = 1;
        int counter = 0;
        Point mousept;
        Point mousestop;
        Pen sidepen = new Pen(Color.Black, 1);
        Brush ballbrush;
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            c = Color.Red;
            toolStripButton1.Checked = true;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = false;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            c = Color.Green;
            toolStripButton1.Checked = false;
            toolStripButton2.Checked = true;
            toolStripButton3.Checked = false;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            c = Color.Blue;
            toolStripButton1.Checked = false;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = true;
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ballPt = new Point(150, 175);
            c = Color.Red;
            ballx = 1;
            bally = 1;
            counter = 0;
            stop = false;
            mousestop = new Point();
            toolStripStatusLabel1.Text = "0";
            toolStripStatusLabel2.Text = "Playing!";
            toolStripButton1.Checked = true;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = false;
            timer1.Start();
            timer2.Start();
            Invalidate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter++;//秒數
            toolStripStatusLabel1.Text = counter.ToString();
            if (counter % 5 == 0 && counter > 1)//每五秒球速變快1倍
            {
                ballx *= 2;
                bally *= 2;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            ballPt.X += ballx;
            ballPt.Y += bally;
            if (ballPt.X >= 300)//右反彈
            {
                ballPt.X = 300;
                ballx *= -1;
            }
            if (ballPt.X <= 0)//左反彈
            {
                ballPt.X = 0;
                ballx *= -1;
            }

            if (ballPt.Y <= 50)//上反彈
            {
                ballPt.Y = 50;
                bally *= -1;
            }
            if (ballPt.Y >= 400)//下反彈
            {
                ballPt.Y = 400;
                bally *= -1;
                if (ballPt.X > mousept.X + 25 || ballPt.X < mousept.X - 5)//當球沒被接到時
                {
                    toolStripStatusLabel2.Text = "Game Over!";
                    timer1.Stop();
                    timer2.Stop();
                    mousestop = new Point(mousept.X, mousept.Y);
                    stop = true;
                }

            }
            Invalidate();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Location.X > 270)
                mousept = new Point(270, 400);
            else if (e.Location.X < 30)
                mousept = new Point(0, 400);
            else
                mousept = new Point(e.Location.X, 400);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.DrawRectangle(sidepen, 0, 50, 300, 350);//畫邊框
            ballbrush = new SolidBrush(c);
            g.FillEllipse(ballbrush, ballPt.X, ballPt.Y, 10, 10);//畫球
            if (stop != true)//先判斷是否gameover，沒的話球持續移動，有的話球不動
                g.FillRectangle(mousebrush, mousept.X, mousept.Y, 30, 10);
            else
                g.FillRectangle(mousebrush, mousestop.X, mousestop.Y, 30, 10);
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "0";
            toolStripStatusLabel2.Text = "Playing!";
            toolStripButton1.Checked = true;
            timer1.Start();
            timer2.Start();
        }
    }
}
